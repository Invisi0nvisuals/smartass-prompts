## Smartass Prompts Project Playbook

Below is the "Smartass Prompts Project Playbook" formatted as a Markdown file (`PROJECT_PLAYBOOK.md`), ready to be saved and dropped into the `/docs/` folder of your new `smartass-prompts` GitHub repository. This version incorporates all the improvements and enhancements discussed, tailored to your Next.js 14+, Tailwind CSS v3, Supabase, Stripe, and Vercel stack, and reflects the lessons learned from the 5050AI project (e.g., AI validation, auth fixes, documentation enforcement).

You can copy the text below into a file named `PROJECT_PLAYBOOK.md` and commit it to your repository, or let Manus AI create the repo with this content as part of the prompt execution. The file is optimized for readability on GitHub and includes the updated prompt for Manus AI to generate the repository.

---

```markdown
# 🧠 **Smartass Prompts Project Playbook**

**Version 1.1 – July 28, 2025**  
*A documentation-first system to scale your prompt marketplace the smartass way.*

---

## 🧩 Overview

This playbook replaces vibe coding with versioned, validated execution. It provides a structured A–Z guide for building, maintaining, and scaling the **Smartass Prompts** platform using **Next.js 14+, Tailwind CSS v3, Supabase, Stripe, and Vercel**.

---

## ✅ Project Scope & Stack

| Layer      | Tech                                   | Rationale                                                   |
| ---------- | -------------------------------------- | ----------------------------------------------------------- |
| Frontend   | Next.js (App Router)                   | SEO, performance, flexibility                               |
| Styling    | Tailwind CSS v3                        | Scalable UI with utility classes                            |
| Backend    | Supabase (PostgreSQL + Auth + Storage) | Firebase alternative w/ RLS, scalable SQL                   |
| Payments   | Stripe (Connect)                       | Secure seller payouts and one-time purchases                |
| Deployment | Vercel                                 | Auto-preview branches + instant CI/CD                       |
| Language   | TypeScript (TSX)                       | Strong typing, error prevention                             |
| Extras     | UploadThing (opt-in), Tiptap, Shiki    | File upload polish, markdown rendering, syntax highlighting |

---

## 🧱 Recommended Repo Structure (`smartass-prompts/`)

```bash
smartass-prompts/
├── app/                    # Next.js App Router
│   ├── page.tsx
│   ├── prompts/
│   ├── dashboard/
│   ├── messages/
│   └── resources/
├── components/             # UI (TSX)
│   ├── PromptCard.tsx
│   ├── PromptUploadForm.tsx
│   └── FilePreview.tsx
├── lib/                    # Supabase, Stripe, AI scoring logic
├── types/                  # TypeScript interfaces
├── public/                 # Static assets
├── styles/
│   └── globals.css
├── docs/                   # Living documentation
│   ├── architecture/
│   ├── auth/
│   ├── components/
│   ├── roadmap.md
│   ├── new-page-template.md
│   └── ai-logs.md         # AI validation logs
├── .env.example
├── .gitignore
├── README.md
├── tsconfig.json
├── tailwind.config.js
├── vercel.json
├── .github/workflows/doc-check.yml  # Doc enforcement
```

---

## 🔄 Git Branch Strategy (Vercel-friendly)

| Branch      | Purpose               | Auto-deployed to                          |
| ----------- | --------------------- | ----------------------------------------- |
| `main`      | Stable public site    | `smartassprompts.com`                     |
| `beta`      | Staging/test site     | `beta.smartassprompts.com`                |
| `feature/*` | PR development        | Vercel preview URLs                       |
| `docs`      | Documentation updates | Optional branch for living playbook edits |

---

## 📖 Playbook Sections

### Part 1: Ideation & Foundation

* **1.1 Mission**
  Democratize access to powerful AI through prompt knowledge exchange.

* **1.2 Personas**
  - *Sellers*: Creators with proven prompts or niche expertise.
  - *Buyers*: Entrepreneurs, marketers, coders, designers seeking shortcut power.

* **1.3 Business Logic**
  - One-time prompt purchases.
  - Stripe payouts via Connect.
  - AI-verified prompt quality badges.

---

### Part 2: Design & Architecture

* **2.1 Component Design Principles**
  - All components in `/components/`, named in PascalCase.
  - Typed via TS interfaces in `/types/`.

* **2.2 Tailwind Config**
  - Use custom colors in `tailwind.config.js`:
    ```js
    module.exports = {
      content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
      theme: {
        extend: {
          colors: {
            'brand-primary': '#4A90E2',
            'gray-soft': '#F5F5F5',
            border: 'hsl(var(--border, 214 31% 91%))',
          },
        },
      },
      plugins: [],
    };
    ```
  - Define `--border` in `globals.css`: `:root { --border: hsl(214, 31%, 91%); }`.

* **2.3 Supabase Schema**
  - Tables: `users`, `prompts`, `purchases`, `messages`, `categories`, `resources`, `prompt_metadata`.
  - RLS: `CREATE POLICY for_prompts ON prompts FOR SELECT USING (auth.uid() = owner_id); CREATE POLICY for_purchases ON purchases FOR SELECT USING (auth.uid() = buyer_id);`.
  - `prompt_metadata`: Stores AI scoring (clarity, structure, etc., 1–10).

* **2.4 Markdown Rendering**
  - Render `prompt.description` with `react-markdown` + `shiki` for syntax highlighting.
  - Strip emojis from slugs (e.g., `prompt.title → /prompt/viral-tiktok-script`).

---

### Part 3: Development Standards

* **3.1 File Naming**
  - No emojis in filenames or GitHub commits.
  - Slugs are kebab-case only.

* **3.2 Upload UX**
  - Use `UploadThing` for media + `.txt` uploads.
  - Validate with `zod` (e.g., `z.object({ file: z.string().max(5 * 1024 * 1024) })`).
  - Store in Supabase Storage.

* **3.3 Prompt Scoring (AI-Evaluator)**
  - On upload, run `lib/aiEvaluator.ts`:
    ```ts
    import { OpenAI } from 'openai';
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const evaluation = await openai.chat.completions.create({
      model: 'gpt-4',
      messages: [{ role: 'user', content: prompt.content }],
    });
    const score = computeScore(evaluation.choices[0].message.content); // 1–10
    ```
  - Auto-tag (e.g., “Expert Crafted”).

* **3.4 AI Code Validation**
  - Validate AI-generated code (e.g., from Copilot): Check Tailwind classes, Supabase queries.
  - Log prompts/results in `docs/ai-logs.md`.

---

### Part 4: Deployment & Operations

* **4.1 Vercel Setup**
  - `main` → production
  - `beta` → staging
  - PRs → auto-previews
  - `.vercelignore`: `/docs/`, test files

* **4.2 Environment Variables**
  - `.env.example`:
    ```
    NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
    SUPABASE_SERVICE_ROLE_KEY=your-key
    STRIPE_SECRET_KEY=sk_test_...
    OPENAI_API_KEY=sk-...
    ```

* **4.3 GitHub Actions**
  - `.github/workflows/doc-check.yml`:
    ```yaml
    name: Doc Check
    on: pull_request
    jobs:
      build:
        runs-on: ubuntu-latest
        steps:
          - uses: actions/checkout@v3
          - run: if [ ! -f "docs/changes.md" ]; then exit 1; fi
    ```

* **4.4 Auth Handling**
  - Set Supabase redirectTo to `/auth/callback`.
  - Add `app/auth/confirm/route.ts`: `export async function GET() { return redirect('/auth'); }`.

---

### Part 5: Documentation Enforcement

* **New Page Template** (`docs/new-page-template.md`):
  ```md
  ## Page Name
  **Route**: /prompts/upload  
  **Purpose**: Allow seller to upload new prompt  
  **Components**: PromptUploadForm, FilePreview  
  **State Logic**: Supabase insert, UploadThing upload  
  **Shell Integration**: Uses default layout.tsx, props: { title: "Upload Prompt" }
  ```

* **CONTRIBUTING.md**:
  - Every PR must update:
    - `/docs/` Markdown (e.g., new page doc).
    - Prop types if TSX changed.
    - Screenshots for major UI changes.

---

## 🎯 Prompt for Manus AI (New Repository Creation)

> "Create a new GitHub repository named `smartass-prompts` for the Smartass Prompts Project Playbook (v1.1, July 28, 2025). Use PAT: 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. Initialize with the recommended repo structure (see Playbook). Implement Phase 1:
> - Set up `/components/PromptUploadForm.tsx` with a drag-and-drop uploader using UploadThing, validated with zod (max 5MB files), and store in Supabase Storage.
> - Create `lib/aiEvaluator.ts` with OpenAI GPT-4 scoring (clarity, structure, usefulness, 1–10) and auto-tagging.
> - Define Supabase `prompt_metadata` table with RLS (owner_id = auth.uid()).
> - Add documentation in `docs/components/PromptUploadForm.md` and `docs/ai/ScoringLogic.md`.
> - Commit to `feature/upload-and-eval`, push to `beta` branch, and trigger Vercel preview. Include `.env.example` with required vars.
> - Validate locally with `pnpm build && pnpm start`, ensure Tailwind v3 styles apply, and provide preview URL."

---

## ✅ Next Actions for You
- [ ] Create GitHub repo `smartass-prompts` (or let Manus do it).
- [ ] Connect `main` and `beta` to Vercel (Settings > Git).
- [ ] Enable Supabase project, create `prompts` bucket.
- [ ] Add `.env.local` from `.env.example` with real keys.
- [ ] Test `/prompts/upload` page + AI scoring locally.
- [ ] Document in `/docs/` from day one.

Would you like this exported as:
- [ ] A full GitHub starter repo (zipped)?
- [ ] Markdown `PROJECT_PLAYBOOK.md` for `/docs/`?
- [ ] GitHub issue templates?
---

Let’s lock this in and prompt like pros!
```

### How to Use
1. **Save the File**: Copy the above text into a file named `PROJECT_PLAYBOOK.md`.
2. **Add to Repo**: Either commit it manually to an existing repo (e.g., `smartass-prompts/docs/`) or let Manus AI create the new repo with this content via the provided prompt.
3. **Execute Prompt**: Send the Manus AI prompt to generate the repository, structure, and initial files.
4. **Next Steps**: Follow the checklist to set up Vercel, Supabase, and test locally.

This Markdown file is ready for your `/docs/` folder and provides a solid foundation for the Smartass Prompts platform. Let me know if you’d like a zipped repo instead or additional tweaks!